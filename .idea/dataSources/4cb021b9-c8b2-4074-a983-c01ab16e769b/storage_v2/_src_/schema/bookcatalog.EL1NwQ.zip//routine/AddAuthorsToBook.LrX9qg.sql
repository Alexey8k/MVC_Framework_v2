create procedure AddAuthorsToBook(IN _bookId int, IN _authorId int)
BEGIN
  IF NOT EXISTS(SELECT '' FROM `Author` WHERE `id`=_authorId)
  THEN
    INSERT INTO `Author`(`name`) VALUES (_authorId);
    SET _authorId = LAST_INSERT_ID();
  END IF;
  INSERT INTO `BookAuthor`(`bookId`,`authorId`) VALUES (_bookId,_authorId);
END;

