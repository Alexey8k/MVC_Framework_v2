create function GetQuantityByFilter(_genreId int, _authorId int) returns int
BEGIN
  DECLARE `_quantityByFilter` INT;
  SELECT COUNT(DISTINCT b.id) INTO `_quantityByFilter` FROM `Book` b
    JOIN `BookGenre` bg ON _genreId IS NULL OR b.id=bg.bookId AND bg.genreId=_genreId
    JOIN `BookAuthor` ba ON _authorId IS NULL OR b.id=ba.bookId AND ba.authorId=_authorId;
  RETURN `_quantityByFilter`;
END;

