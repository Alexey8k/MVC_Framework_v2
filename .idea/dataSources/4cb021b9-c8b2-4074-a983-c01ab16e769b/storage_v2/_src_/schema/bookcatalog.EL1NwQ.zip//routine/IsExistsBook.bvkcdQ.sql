create function IsExistsBook(_id int) returns tinyint(1)
BEGIN
  RETURN EXISTS(SELECT '' FROM `Book` WHERE `id`=_id);
END;

