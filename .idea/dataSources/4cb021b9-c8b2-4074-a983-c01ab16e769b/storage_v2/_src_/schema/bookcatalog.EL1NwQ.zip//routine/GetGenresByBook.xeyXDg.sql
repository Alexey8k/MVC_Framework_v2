create procedure GetGenresByBook(IN _bookId int)
BEGIN
  SELECT g.*
  FROM `BookGenre` bg
         JOIN `Genre` g ON bg.genreId = g.id
  WHERE bg.bookId=_bookId;
END;

