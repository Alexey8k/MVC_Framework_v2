create function SaveBook(_id int, _name varchar(128), _description varchar(512), _price decimal(6, 2)) returns int
BEGIN
  IF IsExistsBook(_id)
  THEN
    UPDATE `Book`
    SET `name`=_name,
        `description`=_description,
        `price`=_price
    WHERE `id`=_id;
    DELETE FROM `BookAuthor` WHERE `bookId`=_id;
    DELETE FROM `BookGenre` WHERE `bookId`=_id;
  ELSE
    INSERT INTO `Book`(`name`,`description`,`price`)
    VALUES (_name,_description,_price);
  END IF;
  RETURN IF(LAST_INSERT_ID(),LAST_INSERT_ID(),_id);
END;

