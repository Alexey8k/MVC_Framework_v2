create procedure GetAuthorsByBook(IN _bookId int)
BEGIN
  SELECT a.*
  FROM `BookAuthor` ba
         JOIN `Author` a ON ba.authorId = a.id
  WHERE ba.bookId=_bookId;
END;

