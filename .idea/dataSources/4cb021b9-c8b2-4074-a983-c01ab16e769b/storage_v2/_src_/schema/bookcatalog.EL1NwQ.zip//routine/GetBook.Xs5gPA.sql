create procedure GetBook(IN _id int)
BEGIN
  SELECT * FROM `Book` WHERE `id`=_id LIMIT 1;
  CALL GetAuthorsByBook(_id);
  CALL GetGenresByBook(_id);
END;

