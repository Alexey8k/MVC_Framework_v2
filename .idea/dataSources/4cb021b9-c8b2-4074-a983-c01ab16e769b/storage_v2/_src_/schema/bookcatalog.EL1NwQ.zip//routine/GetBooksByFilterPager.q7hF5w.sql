create procedure GetBooksByFilterPager(IN _genreId int, IN _authorId int, IN _page int, IN _count int)
BEGIN
  DECLARE _offset INT DEFAULT (_page-1)*_count;
  SELECT b.* FROM `Book` b
    JOIN `BookGenre` bg ON _genreId IS NULL OR b.id=bg.bookId AND bg.genreId=_genreId
    JOIN `BookAuthor` ba ON _authorId IS NULL OR b.id=ba.bookId AND ba.authorId=_authorId
    GROUP BY b.id
    LIMIT _offset, _count;
END;

