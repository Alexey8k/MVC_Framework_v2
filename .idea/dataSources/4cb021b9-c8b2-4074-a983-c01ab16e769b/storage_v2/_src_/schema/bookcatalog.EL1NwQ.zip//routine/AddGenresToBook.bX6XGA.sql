create procedure AddGenresToBook(IN _bookId int, IN _genreId varchar(128))
BEGIN
  IF NOT EXISTS(SELECT '' FROM `Genre` WHERE `id`=CAST(_genreId AS UNSIGNED))
  THEN
    INSERT INTO `Genre`(`name`) VALUES (_genreId);
    SET _genreId = LAST_INSERT_ID();
  END IF;
  INSERT INTO `BookGenre`(`bookId`,`genreId`) VALUES (_bookId,_genreId);
END;

